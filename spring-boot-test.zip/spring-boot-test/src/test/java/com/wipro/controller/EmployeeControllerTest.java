package com.wipro.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EmployeeControllerTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
