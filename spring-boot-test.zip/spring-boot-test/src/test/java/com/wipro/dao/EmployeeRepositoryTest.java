package com.wipro.dao;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

class EmployeeRepositoryTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
