package com.wipro.controller;

import org.springframework.web.bind.annotation.RequestMapping;

public class HelloController {
	
	@RequestMapping("/hello")
	public String sayHello() {
		return "Hello, Welcome To Spring Boot Application";
	}

}
